using System.Drawing;
using System.Data.SqlClient;


namespace ATM_HG_FINAL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void registerBtn_Click(object sender, EventArgs e)
        {
            //the initial balancec is zero w/c mean that a person can be registered with assumtion of 0 birr
            int bal = 0;
            //check if the textbox are missing or not
            if (AccNumTxtbox.Text == "" || addressTxtbox.Text == "" || fNameTxtbox.Text == "" || lNameTxtbox.Text == "" || phoneTxtbox.Text == "" || PinTxtbox.Text == "" || genderCBox.Text == "" || DOBdateTimePicker.Text == "")
            {
                MessageBox.Show("Missing Information.Please Make  Sure You Have Entered All Information");
            }
            else
            {
                try
                {
                    //open the connection
                    con.Open();
                    // query to insert the information from the textboxes to the datebase tabele 
                    string query = "insert into AccountTbl values( '" + AccNumTxtbox.Text + "', '" + fNameTxtbox.Text + "','" + lNameTxtbox.Text + "','" + DOBdateTimePicker.Text + "','" + phoneTxtbox.Text + "','" + addressTxtbox.Text + "','" + genderCBox.Text + "','" + PinTxtbox.Text + "'," + bal + ")";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Account created successfully");

                    //must close the connection
                    con.Close();
                    //then it goes to the login page
                    LoginForm log = new LoginForm();
                    log.Show();
                    this.Hide();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }


        }

        private void logoutLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //then it goes to the login page
            LoginForm log = new LoginForm();
            log.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {//when the "X" is clicked it close the application
            Application.Exit();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            //then it goes to the login page
            DeleteForm2 delete = new DeleteForm2();
            delete.Show();
            this.Hide();

        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            SearchForm search = new SearchForm();
            search.Show();
            this.Hide();

        }
    }
}
