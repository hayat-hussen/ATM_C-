﻿namespace ATM_HG_FINAL
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            label1 = new Label();
            PinTxtbox = new TextBox();
            AccNumTxtbox = new TextBox();
            signupBtn = new Button();
            loginBtn = new Button();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label4.Location = new Point(56, 236);
            label4.Name = "label4";
            label4.Size = new Size(112, 25);
            label4.TabIndex = 13;
            label4.Text = "PIN Code";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // PinTxtbox
            // 
            PinTxtbox.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            PinTxtbox.Location = new Point(305, 227);
            PinTxtbox.Name = "PinTxtbox";
            PinTxtbox.Size = new Size(362, 34);
            PinTxtbox.TabIndex = 17;
            // 
            // AccNumTxtbox
            // 
            AccNumTxtbox.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            AccNumTxtbox.Location = new Point(305, 150);
            AccNumTxtbox.Name = "AccNumTxtbox";
            AccNumTxtbox.Size = new Size(362, 34);
            AccNumTxtbox.TabIndex = 16;
            // 
            // signupBtn
            // 
            signupBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            signupBtn.Location = new Point(373, 387);
            signupBtn.Name = "signupBtn";
            signupBtn.Size = new Size(94, 42);
            signupBtn.TabIndex = 15;
            signupBtn.Text = "Signup";
            signupBtn.UseVisualStyleBackColor = true;
            signupBtn.Click += signupBtn_Click;
            // 
            // loginBtn
            // 
            loginBtn.BackColor = Color.FromArgb(0, 64, 64);
            loginBtn.BackgroundImageLayout = ImageLayout.None;
            loginBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            loginBtn.Location = new Point(343, 318);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(162, 49);
            loginBtn.TabIndex = 14;
            loginBtn.Text = "Login";
            loginBtn.UseVisualStyleBackColor = false;
            loginBtn.Click += loginBtn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label3.Location = new Point(56, 150);
            label3.Name = "label3";
            label3.Size = new Size(185, 25);
            label3.TabIndex = 12;
            label3.Text = "Account Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label2.Location = new Point(373, 83);
            label2.Name = "label2";
            label2.Size = new Size(89, 25);
            label2.TabIndex = 11;
            label2.Text = "LOGIN";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 10;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(panel1);
            Controls.Add(PinTxtbox);
            Controls.Add(AccNumTxtbox);
            Controls.Add(signupBtn);
            Controls.Add(loginBtn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoginForm";
            Text = "LoginForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private Panel panel1;
        private Label label5;
        private Label label1;
        private TextBox PinTxtbox;
        private TextBox AccNumTxtbox;
        private Button signupBtn;
        private Button loginBtn;
        private Label label3;
        private Label label2;
        private Panel panel2;
    }
}