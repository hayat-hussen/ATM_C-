﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ATM_HG_FINAL
{
    public partial class BalanceForm : Form
    {
        public BalanceForm()
        {
            InitializeComponent();
        }
        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void backBtn_Click(object sender, EventArgs e)
        {
            //then it goes to the HomeForm page
            HomeForm hf = new HomeForm();
            this.Hide();
            hf.Show();
        }




        private void label5_Click(object sender, EventArgs e)
        { //when the "X" is clicked it close the application
            Application.Exit();

        }

        private void logoutLinkLable_LinkClicked(object sender, EventArgs e)
        { //then it goes to the login page
            LoginForm log = new LoginForm();
            this.Hide();
            log.Show();

        }

        private void BalanceForm_Load(object sender, EventArgs e)
        {
            //take the account number frim homeform page and display at accNumLabel on balance page
            accNumLabel.Text = HomeForm.AccNum;


            //to display the balance w/c can be accesed though BD connection

            //open the connection
            con.Open();
            // query to insert the information from the textboxes to the datebase tabele 
            string query = "select Balance from AccountTbl where Accnum = '" + accNumLabel.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                balanceLable.Text = dt.Rows[0][0].ToString() + " Birr";
            }
            con.Close();


        }
    }
}
