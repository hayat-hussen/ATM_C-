﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ATM_HG_FINAL
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void signupBtn_Click(object sender, EventArgs e)
        {// when signin btn click it goes to the admin page 
            AdminForm admin = new AdminForm();
            admin.Show();
           this.Hide();

        }

        public static string AccNumber;
        private void loginBtn_Click(object sender, EventArgs e)
        {
          //when the login btn click check if the acc num and PIN are correct the log to the home page 
         //open the connection
            con.Open();
            // query to select from datebase tabele 
            string query = "select count(*) from AccountTbl where Accnum= '" + AccNumTxtbox.Text + "'and PIN= '" + PinTxtbox.Text + "' ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {
                AccNumber = AccNumTxtbox.Text;
                HomeForm homeForm = new HomeForm();
                homeForm.Show();
                this.Hide();
                con.Close();

            }
            else
            {
                MessageBox.Show("Wrong Account Number Or PIN");


            }
            con.Close();

        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            //when the "X" is clicked it close the application
            Application.Exit();
        }

      
    }
}
