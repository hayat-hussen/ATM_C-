﻿namespace ATM_HG_FINAL
{
    partial class DeleteForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label5 = new Label();
            label1 = new Label();
            deleteBtn = new Button();
            AccNumTxtbox = new TextBox();
            backBtn = new Button();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.FromArgb(0, 64, 64);
            deleteBtn.BackgroundImageLayout = ImageLayout.None;
            deleteBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            deleteBtn.Location = new Point(343, 318);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(162, 49);
            deleteBtn.TabIndex = 23;
            deleteBtn.Text = "Delete";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // AccNumTxtbox
            // 
            AccNumTxtbox.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            AccNumTxtbox.Location = new Point(287, 195);
            AccNumTxtbox.Name = "AccNumTxtbox";
            AccNumTxtbox.Size = new Size(362, 34);
            AccNumTxtbox.TabIndex = 25;
            // 
            // backBtn
            // 
            backBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            backBtn.Location = new Point(373, 387);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(94, 42);
            backBtn.TabIndex = 24;
            backBtn.Text = "Back";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label3.Location = new Point(38, 195);
            label3.Name = "label3";
            label3.Size = new Size(185, 25);
            label3.TabIndex = 21;
            label3.Text = "Account Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label2.Location = new Point(373, 83);
            label2.Name = "label2";
            label2.Size = new Size(164, 25);
            label2.TabIndex = 20;
            label2.Text = "Delete Account";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 19;
            // 
            // DeleteForm2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(deleteBtn);
            Controls.Add(AccNumTxtbox);
            Controls.Add(backBtn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "DeleteForm2";
            Text = "DeleteForm2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label5;
        private Label label1;
        private Button deleteBtn;
        private TextBox AccNumTxtbox;
        private Button backBtn;
        private Label label3;
        private Label label2;
        private Panel panel2;
    }
}