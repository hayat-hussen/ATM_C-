﻿namespace ATM_HG_FINAL
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            genderCBox = new ComboBox();
            DOBdateTimePicker = new DateTimePicker();
            label8 = new Label();
            label9 = new Label();
            phoneTxtbox = new TextBox();
            addressTxtbox = new TextBox();
            label10 = new Label();
            label11 = new Label();
            fNameTxtbox = new TextBox();
            lNameTxtbox = new TextBox();
            label6 = new Label();
            label7 = new Label();
            PinTxtbox = new TextBox();
            registerBtn = new Button();
            label4 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            label5 = new Label();
            label1 = new Label();
            AccNumTxtbox = new TextBox();
            panel1 = new Panel();
            label3 = new Label();
            logoutLinkLabel = new LinkLabel();
            deleteBtn = new Button();
            searchBtn = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // genderCBox
            // 
            genderCBox.FormattingEnabled = true;
            genderCBox.Items.AddRange(new object[] { "Female", "male" });
            genderCBox.Location = new Point(532, 181);
            genderCBox.Name = "genderCBox";
            genderCBox.Size = new Size(258, 28);
            genderCBox.TabIndex = 52;
            // 
            // DOBdateTimePicker
            // 
            DOBdateTimePicker.Location = new Point(527, 239);
            DOBdateTimePicker.Name = "DOBdateTimePicker";
            DOBdateTimePicker.Size = new Size(263, 27);
            DOBdateTimePicker.TabIndex = 51;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label8.Location = new Point(394, 299);
            label8.Name = "label8";
            label8.Size = new Size(78, 23);
            label8.TabIndex = 50;
            label8.Text = "Address";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label9.Location = new Point(394, 246);
            label9.Name = "label9";
            label9.Size = new Size(127, 23);
            label9.TabIndex = 49;
            label9.Text = "Date Of Birth";
            // 
            // phoneTxtbox
            // 
            phoneTxtbox.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            phoneTxtbox.Location = new Point(532, 115);
            phoneTxtbox.Name = "phoneTxtbox";
            phoneTxtbox.Size = new Size(258, 30);
            phoneTxtbox.TabIndex = 47;
            // 
            // addressTxtbox
            // 
            addressTxtbox.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            addressTxtbox.Location = new Point(517, 292);
            addressTxtbox.Name = "addressTxtbox";
            addressTxtbox.Size = new Size(261, 30);
            addressTxtbox.TabIndex = 48;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label10.Location = new Point(394, 182);
            label10.Name = "label10";
            label10.Size = new Size(74, 23);
            label10.TabIndex = 46;
            label10.Text = "Gender";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label11.Location = new Point(394, 122);
            label11.Name = "label11";
            label11.Size = new Size(91, 23);
            label11.TabIndex = 45;
            label11.Text = "Phone No";
            // 
            // fNameTxtbox
            // 
            fNameTxtbox.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            fNameTxtbox.Location = new Point(148, 239);
            fNameTxtbox.Name = "fNameTxtbox";
            fNameTxtbox.Size = new Size(207, 30);
            fNameTxtbox.TabIndex = 43;
            // 
            // lNameTxtbox
            // 
            lNameTxtbox.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            lNameTxtbox.Location = new Point(148, 292);
            lNameTxtbox.Name = "lNameTxtbox";
            lNameTxtbox.Size = new Size(207, 30);
            lNameTxtbox.TabIndex = 44;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label6.Location = new Point(10, 299);
            label6.Name = "label6";
            label6.Size = new Size(102, 23);
            label6.TabIndex = 42;
            label6.Text = "Last Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label7.Location = new Point(10, 246);
            label7.Name = "label7";
            label7.Size = new Size(103, 23);
            label7.TabIndex = 41;
            label7.Text = "Frist Name";
            // 
            // PinTxtbox
            // 
            PinTxtbox.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            PinTxtbox.Location = new Point(148, 175);
            PinTxtbox.Name = "PinTxtbox";
            PinTxtbox.Size = new Size(207, 30);
            PinTxtbox.TabIndex = 40;
            // 
            // registerBtn
            // 
            registerBtn.BackColor = Color.FromArgb(0, 64, 64);
            registerBtn.BackgroundImageLayout = ImageLayout.None;
            registerBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            registerBtn.Location = new Point(171, 357);
            registerBtn.Name = "registerBtn";
            registerBtn.Size = new Size(162, 62);
            registerBtn.TabIndex = 37;
            registerBtn.Text = "Register";
            registerBtn.UseVisualStyleBackColor = false;
            registerBtn.Click += registerBtn_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label4.Location = new Point(10, 190);
            label4.Name = "label4";
            label4.Size = new Size(92, 23);
            label4.TabIndex = 36;
            label4.Text = "PIN Code";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label2.Location = new Point(367, 80);
            label2.Name = "label2";
            label2.Size = new Size(101, 25);
            label2.TabIndex = 34;
            label2.Text = "SIGNUP";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(0, 436);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 33;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 10;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // AccNumTxtbox
            // 
            AccNumTxtbox.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            AccNumTxtbox.Location = new Point(148, 115);
            AccNumTxtbox.Name = "AccNumTxtbox";
            AccNumTxtbox.Size = new Size(204, 30);
            AccNumTxtbox.TabIndex = 39;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 32;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11.8F, FontStyle.Bold);
            label3.Location = new Point(10, 122);
            label3.Name = "label3";
            label3.Size = new Size(108, 23);
            label3.TabIndex = 35;
            label3.Text = "Account No";
            // 
            // logoutLinkLabel
            // 
            logoutLinkLabel.AutoSize = true;
            logoutLinkLabel.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLabel.Location = new Point(691, 399);
            logoutLinkLabel.Name = "logoutLinkLabel";
            logoutLinkLabel.Size = new Size(56, 20);
            logoutLinkLabel.TabIndex = 53;
            logoutLinkLabel.TabStop = true;
            logoutLinkLabel.Text = "Logout";
            logoutLinkLabel.LinkClicked += logoutLinkLabel_LinkClicked;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.White;
            deleteBtn.BackgroundImageLayout = ImageLayout.None;
            deleteBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            deleteBtn.Location = new Point(402, 380);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(119, 39);
            deleteBtn.TabIndex = 54;
            deleteBtn.Text = "Delete";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.White;
            searchBtn.BackgroundImageLayout = ImageLayout.None;
            searchBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            searchBtn.Location = new Point(532, 380);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(119, 39);
            searchBtn.TabIndex = 55;
            searchBtn.Text = "Search";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchBtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(searchBtn);
            Controls.Add(deleteBtn);
            Controls.Add(logoutLinkLabel);
            Controls.Add(genderCBox);
            Controls.Add(DOBdateTimePicker);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(phoneTxtbox);
            Controls.Add(addressTxtbox);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(fNameTxtbox);
            Controls.Add(lNameTxtbox);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(PinTxtbox);
            Controls.Add(registerBtn);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(panel2);
            Controls.Add(AccNumTxtbox);
            Controls.Add(panel1);
            Controls.Add(label3);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox genderCBox;
        private DateTimePicker DOBdateTimePicker;
        private Label label8;
        private Label label9;
        private TextBox phoneTxtbox;
        private TextBox addressTxtbox;
        private Label label10;
        private Label label11;
        private TextBox fNameTxtbox;
        private TextBox lNameTxtbox;
        private Label label6;
        private Label label7;
        private TextBox PinTxtbox;
        private Button registerBtn;
        private Label label4;
        private Label label2;
        private Panel panel2;
        private Label label5;
        private Label label1;
        private TextBox AccNumTxtbox;
        private Panel panel1;
        private Label label3;
        private LinkLabel logoutLinkLabel;
        private Button deleteBtn;
        private Button searchBtn;
    }
}
