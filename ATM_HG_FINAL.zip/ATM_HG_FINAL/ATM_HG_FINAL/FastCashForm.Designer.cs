﻿namespace ATM_HG_FINAL
{
    partial class FastCashForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            panel1 = new Panel();
            label1 = new Label();
            label2 = new Label();
            logoutLinkLable = new LinkLabel();
            b3000Btn = new Button();
            b2000Btn = new Button();
            b1000Btn = new Button();
            b4000Btn = new Button();
            b5000Btn = new Button();
            b500Btn = new Button();
            AccountNumLabel = new Label();
            panel2 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label2.Location = new Point(258, 80);
            label2.Name = "label2";
            label2.Size = new Size(185, 25);
            label2.TabIndex = 42;
            label2.Text = "Account Number";
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(717, 407);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(71, 25);
            logoutLinkLable.TabIndex = 41;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Logout";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked;
            // 
            // b3000Btn
            // 
            b3000Btn.BackColor = Color.FromArgb(0, 64, 64);
            b3000Btn.BackgroundImageLayout = ImageLayout.None;
            b3000Btn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            b3000Btn.Location = new Point(465, 157);
            b3000Btn.Name = "b3000Btn";
            b3000Btn.Size = new Size(162, 49);
            b3000Btn.TabIndex = 40;
            b3000Btn.Text = "3000";
            b3000Btn.UseVisualStyleBackColor = false;
            b3000Btn.Click += b3000Btn_Click;
            // 
            // b2000Btn
            // 
            b2000Btn.BackColor = Color.FromArgb(0, 64, 64);
            b2000Btn.BackgroundImageLayout = ImageLayout.None;
            b2000Btn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            b2000Btn.Location = new Point(106, 360);
            b2000Btn.Name = "b2000Btn";
            b2000Btn.Size = new Size(162, 49);
            b2000Btn.TabIndex = 39;
            b2000Btn.Text = "2000";
            b2000Btn.UseVisualStyleBackColor = false;
            b2000Btn.Click += b2000Btn_Click;
            // 
            // b1000Btn
            // 
            b1000Btn.BackColor = Color.FromArgb(0, 64, 64);
            b1000Btn.BackgroundImageLayout = ImageLayout.None;
            b1000Btn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            b1000Btn.Location = new Point(106, 253);
            b1000Btn.Name = "b1000Btn";
            b1000Btn.Size = new Size(162, 49);
            b1000Btn.TabIndex = 38;
            b1000Btn.Text = "1000";
            b1000Btn.UseVisualStyleBackColor = false;
            b1000Btn.Click += b1000Btn_Click;
            // 
            // b4000Btn
            // 
            b4000Btn.BackColor = Color.FromArgb(0, 64, 64);
            b4000Btn.BackgroundImageLayout = ImageLayout.None;
            b4000Btn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            b4000Btn.Location = new Point(465, 253);
            b4000Btn.Name = "b4000Btn";
            b4000Btn.Size = new Size(162, 49);
            b4000Btn.TabIndex = 37;
            b4000Btn.Text = "4000";
            b4000Btn.UseVisualStyleBackColor = false;
            b4000Btn.Click += b4000Btn_Click;
            // 
            // b5000Btn
            // 
            b5000Btn.BackColor = Color.FromArgb(0, 64, 64);
            b5000Btn.BackgroundImageLayout = ImageLayout.None;
            b5000Btn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            b5000Btn.Location = new Point(465, 360);
            b5000Btn.Name = "b5000Btn";
            b5000Btn.Size = new Size(162, 49);
            b5000Btn.TabIndex = 36;
            b5000Btn.Text = "5000";
            b5000Btn.UseVisualStyleBackColor = false;
            b5000Btn.Click += b5000Btn_Click;
            // 
            // b500Btn
            // 
            b500Btn.BackColor = Color.FromArgb(0, 64, 64);
            b500Btn.BackgroundImageLayout = ImageLayout.None;
            b500Btn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            b500Btn.Location = new Point(106, 157);
            b500Btn.Name = "b500Btn";
            b500Btn.Size = new Size(162, 49);
            b500Btn.TabIndex = 35;
            b500Btn.Text = "500";
            b500Btn.UseVisualStyleBackColor = false;
            b500Btn.Click += b500Btn_Click;
            // 
            // AccountNumLabel
            // 
            AccountNumLabel.AutoSize = true;
            AccountNumLabel.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            AccountNumLabel.Location = new Point(449, 80);
            AccountNumLabel.Name = "AccountNumLabel";
            AccountNumLabel.Size = new Size(185, 25);
            AccountNumLabel.TabIndex = 34;
            AccountNumLabel.Text = "Account Number";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 33;
            // 
            // FastCashForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(logoutLinkLable);
            Controls.Add(b3000Btn);
            Controls.Add(b2000Btn);
            Controls.Add(b1000Btn);
            Controls.Add(b4000Btn);
            Controls.Add(b5000Btn);
            Controls.Add(b500Btn);
            Controls.Add(AccountNumLabel);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FastCashForm";
            Text = "FastCashForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Panel panel1;
        private Label label1;
        private Label label2;
        private LinkLabel logoutLinkLable;
        private Button b3000Btn;
        private Button b2000Btn;
        private Button b1000Btn;
        private Button b4000Btn;
        private Button b5000Btn;
        private Button b500Btn;
        private Label AccountNumLabel;
        private Panel panel2;
    }
}