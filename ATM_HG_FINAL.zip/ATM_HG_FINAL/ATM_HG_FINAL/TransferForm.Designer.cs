﻿namespace ATM_HG_FINAL
{
    partial class TransferForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            label4 = new Label();
            amountTxtbox = new TextBox();
            backBtn = new Button();
            label2 = new Label();
            panel2 = new Panel();
            accountNumTxtbox = new TextBox();
            transfer1Btn = new Button();
            logoutLinkLable = new LinkLabel();
            label6 = new Label();
            reasonTxtbox = new TextBox();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label3.Location = new Point(62, 137);
            label3.Name = "label3";
            label3.Size = new Size(204, 29);
            label3.TabIndex = 45;
            label3.Text = "Account Number:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 42;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label4.Location = new Point(62, 207);
            label4.Name = "label4";
            label4.Size = new Size(108, 29);
            label4.TabIndex = 49;
            label4.Text = "Amount:";
            // 
            // amountTxtbox
            // 
            amountTxtbox.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            amountTxtbox.Location = new Point(283, 207);
            amountTxtbox.Name = "amountTxtbox";
            amountTxtbox.Size = new Size(362, 36);
            amountTxtbox.TabIndex = 50;
            // 
            // backBtn
            // 
            backBtn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            backBtn.Location = new Point(363, 386);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(107, 42);
            backBtn.TabIndex = 47;
            backBtn.Text = "BACK";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label2.Location = new Point(322, 91);
            label2.Name = "label2";
            label2.Size = new Size(148, 29);
            label2.TabIndex = 44;
            label2.Text = "TRANSFER";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 43;
            // 
            // accountNumTxtbox
            // 
            accountNumTxtbox.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            accountNumTxtbox.Location = new Point(283, 137);
            accountNumTxtbox.Name = "accountNumTxtbox";
            accountNumTxtbox.Size = new Size(362, 36);
            accountNumTxtbox.TabIndex = 48;
            // 
            // transfer1Btn
            // 
            transfer1Btn.BackColor = Color.FromArgb(0, 64, 64);
            transfer1Btn.BackgroundImageLayout = ImageLayout.None;
            transfer1Btn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            transfer1Btn.Location = new Point(342, 315);
            transfer1Btn.Name = "transfer1Btn";
            transfer1Btn.Size = new Size(162, 65);
            transfer1Btn.TabIndex = 46;
            transfer1Btn.Text = "Transfer";
            transfer1Btn.UseVisualStyleBackColor = false;
            transfer1Btn.Click += transfer1Btn_Click;
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(694, 397);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(71, 25);
            logoutLinkLable.TabIndex = 52;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Logout";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label6.Location = new Point(62, 272);
            label6.Name = "label6";
            label6.Size = new Size(99, 29);
            label6.TabIndex = 53;
            label6.Text = "Reason:";
            // 
            // reasonTxtbox
            // 
            reasonTxtbox.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            reasonTxtbox.Location = new Point(283, 272);
            reasonTxtbox.Name = "reasonTxtbox";
            reasonTxtbox.Size = new Size(362, 36);
            reasonTxtbox.TabIndex = 54;
            // 
            // TransferForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(reasonTxtbox);
            Controls.Add(logoutLinkLable);
            Controls.Add(label3);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(amountTxtbox);
            Controls.Add(backBtn);
            Controls.Add(label2);
            Controls.Add(panel2);
            Controls.Add(accountNumTxtbox);
            Controls.Add(transfer1Btn);
            FormBorderStyle = FormBorderStyle.None;
            Name = "TransferForm";
            Text = "TransferForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Panel panel1;
        private Label label5;
        private Label label4;
        private TextBox amountTxtbox;
        private Button backBtn;
        private Label label2;
        private Panel panel2;
        private TextBox accountNumTxtbox;
        private Button transfer1Btn;
        private LinkLabel logoutLinkLable;
        private Label label6;
        private TextBox reasonTxtbox;
    }
}