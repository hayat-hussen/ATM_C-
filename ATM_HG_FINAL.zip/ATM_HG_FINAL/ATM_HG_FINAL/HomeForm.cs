﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ATM_HG_FINAL
{
    public partial class HomeForm : Form
    {
        public HomeForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            //when the "X" is clicked it close the application
            Application.Exit();
        }



        private void balanceBtn_Click(object sender, EventArgs e)
        {
            //then it goes to the BalanceForm page
            BalanceForm bf = new BalanceForm();
            this.Hide();
            bf.Show();


        }

        private void changeBtn_Click(object sender, EventArgs e)
        {

            //then it goes to the ChangePINForm page
            ChangePINForm cpf = new ChangePINForm();
            this.Hide();
            cpf.Show();

        }

        private void depositeBtn_Click(object sender, EventArgs e)
        {
            //then it goes to the  DepositForm2cs  page
            DepositForm2cs df = new DepositForm2cs();
            this.Hide();
            df.Show();

        }

        private void withdrawBtn_Click(object sender, EventArgs e)
        {

            //then it goes to the  WthdrawForm  page
            WthdrawForm wdf = new WthdrawForm();
            this.Hide();
            wdf.Show();

        }

        private void transferBtn_Click(object sender, EventArgs e)
        {
            //then it goes to the   TransferForm  page
            TransferForm tf = new TransferForm();
            this.Hide();
            tf.Show();

        }

        private void logoutLinkLable_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //then it goes to the login page
            LoginForm log = new LoginForm();
            this.Hide();
            log.Show();

        }
        public static string AccNum;

        private void HomeForm_Load(object sender, EventArgs e)
        {
            AccountNumLabel.Text = LoginForm.AccNumber;
            AccNum = AccountNumLabel.Text;
        }

        private void fastcshBtn_Click(object sender, EventArgs e)
        {
            FastCashForm fastcash = new FastCashForm();
            this.Hide();
            fastcash.Show();

        }
    }
}
