﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ATM_HG_FINAL
{
    public partial class ChangePINForm : Form
    {
        public ChangePINForm()
        {
            InitializeComponent();
        }
        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void label5_Click(object sender, EventArgs e)
        {
            //when the "X" is clicked it close the application
            Application.Exit();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            // then it goes to the HomeForm page
            HomeForm hf = new HomeForm();
            this.Hide();
            hf.Show();
        }

        private void logoutLinkLable_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //then it goes to the login page
            LoginForm log = new LoginForm();
            this.Hide();
            log.Show();
        }

        private void deposit1Btn_Click(object sender, EventArgs e)
        {
            string AccNum = HomeForm.AccNum;
            if (confirmPINTxtbox.Text == newPINTxtbox.Text) {
            }
            else {
                MessageBox.Show("confirmPIN and newPIN Does Not Match.Please Write Again");
            }
            //open the connection
            con.Open();
            string query = "UPDATE AccountTbl SET PIN = '"+newPINTxtbox.Text+"' WHERE AccNum = '"+AccNum+"'";
            SqlCommand cmd = new SqlCommand(query, con);
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                // Update successful, show message
                MessageBox.Show("PIN updated successfully!");
            }
            else
            {
                // Update failed, handle error
                MessageBox.Show("Error updating PIN!");
            }

        }
    }
}
