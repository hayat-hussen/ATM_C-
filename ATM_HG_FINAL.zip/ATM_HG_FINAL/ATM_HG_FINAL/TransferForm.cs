﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ATM_HG_FINAL
{
    public partial class TransferForm : Form
    {
        public TransferForm()
        {
            InitializeComponent();
        }
        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void label5_Click(object sender, EventArgs e)
        {
            //when the "X" is clicked it close the application
            Application.Exit();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            // then it goes to the HomeForm page
            HomeForm hf = new HomeForm();
            this.Hide();
            hf.Show();
        }

        private void logoutLinkLable_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //then it goes to the login page
            LoginForm log = new LoginForm();
            this.Hide();
            log.Show();
        }

        public string AccNum = HomeForm.AccNum;
        string date = DateTime.Now.ToString("dd MMMM yyyy");


        private void transfer1Btn_Click(object sender, EventArgs e)
        {

           
                con.Open();

                // Assuming you have a TextBox for entering the receiver's account number
                string receiverAccountNumber = accountNumTxtbox.Text.Trim();

                SqlDataAdapter senderDataAdapter = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
                DataTable senderDataTable = new DataTable();
                senderDataAdapter.Fill(senderDataTable);

                SqlDataAdapter receiverDataAdapter = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + receiverAccountNumber + "'", con);
                DataTable receiverDataTable = new DataTable();
                receiverDataAdapter.Fill(receiverDataTable);

                int senderBalance = Convert.ToInt32(senderDataTable.Rows[0][0].ToString());

                if (amountTxtbox.Text == "" || receiverAccountNumber == "")
                {
                    MessageBox.Show("Enter the Amount and Receiver's Account Number");
                }
                else if (Convert.ToInt32(amountTxtbox.Text) <= 0)
                {
                    MessageBox.Show("Not a valid amount");
                }
                else if (Convert.ToInt32(amountTxtbox.Text) > senderBalance)
                {
                    MessageBox.Show("Not sufficient balance in the sender's account");
                }
                else
                {
                    try
                    {
                        int receiverBalance = Convert.ToInt32(receiverDataTable.Rows[0][0].ToString());

                        int amountToTransfer = Convert.ToInt32(amountTxtbox.Text);

                        int newSenderBalance = senderBalance - amountToTransfer;
                        int newReceiverBalance = receiverBalance + amountToTransfer;

                        string senderQuery = "update AccountTbl set Balance = " + newSenderBalance + " where Accnum = '" + AccNum + "'";
                        string receiverQuery = "update AccountTbl set Balance = " + newReceiverBalance + " where Accnum = '" + receiverAccountNumber + "'";

                        SqlCommand senderCmd = new SqlCommand(senderQuery, con);
                        SqlCommand receiverCmd = new SqlCommand(receiverQuery, con);

                        // Use a transaction to ensure that both updates succeed or fail together
                        using (SqlTransaction transaction = con.BeginTransaction())
                        {
                            try
                            {
                                senderCmd.Transaction = transaction;
                                receiverCmd.Transaction = transaction;

                                senderCmd.ExecuteNonQuery();
                                receiverCmd.ExecuteNonQuery();

                                transaction.Commit();

                                MessageBox.Show("Transfer successful!");
                                HomeForm hm = new HomeForm();
                                hm.Show();
                                this.Hide();
                            }
                            catch (Exception ex)
                            {
                                transaction.Rollback();
                                MessageBox.Show("Transfer failed: " + ex.Message);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

                con.Close();
            

        }
    }
}