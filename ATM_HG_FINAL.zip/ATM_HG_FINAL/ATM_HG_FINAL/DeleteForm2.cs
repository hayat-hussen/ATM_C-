﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATM_HG_FINAL
{
    public partial class DeleteForm2 : Form
    {
        public DeleteForm2()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

            //when the "X" is clicked it close the application
            Application.Exit();
        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

      
            private void DeleteAccount(string accountNumber)
            {
                try
                {
                    con.Open();

                    string query = "DELETE FROM AccountTbl WHERE AccNum = @AccountNumber";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@AccountNumber", accountNumber);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Account deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Account not found or deletion failed.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string accountNumberToDelete = AccNumTxtbox.Text.Trim();

                if (!string.IsNullOrEmpty(accountNumberToDelete))
                {
                    DeleteAccount(accountNumberToDelete);
                }
                else
                {
                    MessageBox.Show("Please enter an account number to delete.");
                }
            }
        
   

        

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1();
            back.Show();
            this.Hide();

        }
    }
}
