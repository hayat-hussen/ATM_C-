﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_HG_FINAL
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

            //when the "X" is clicked it close the application
            Application.Exit();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1();
            back.Show();
            this.Hide();
        }
        private void SearchAndDisplayData()
        {
            try
            {
                con.Open();
                string AccNum = AccNumTxtbox.Text;

                string query = "SELECT * FROM AccountTbl WHERE Accnum LIKE @AccNum + '%'  ";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                sda.SelectCommand.Parameters.AddWithValue("@AccNum", AccNumTxtbox.Text);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    // Display the result in the DataGridView
                    dataGridView.DataSource = dt;

                    // Store the account number for future reference
                    AccNum = AccNumTxtbox.Text;

                }
                else
                {
                    MessageBox.Show("Account not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

            con.Close();

        }
        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void AccNumTxtbox_TextChanged(object sender, EventArgs e)
        {
            // Call the method to search and display data
            SearchAndDisplayData();
        }

       

        private void AccNumTxtbox_TextChanged_1(object sender, EventArgs e)
        {
            SearchAndDisplayData();
        }
    }
}



