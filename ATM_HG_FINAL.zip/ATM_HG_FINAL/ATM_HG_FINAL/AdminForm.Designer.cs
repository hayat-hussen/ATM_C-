﻿namespace ATM_HG_FINAL
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            panel1 = new Panel();
            label1 = new Label();
            loginBtn = new Button();
            panel2 = new Panel();
            label2 = new Label();
            nametxtbox = new TextBox();
            pintxtbox = new TextBox();
            label3 = new Label();
            logoutLinkLable = new LinkLabel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // loginBtn
            // 
            loginBtn.BackColor = Color.FromArgb(0, 64, 64);
            loginBtn.BackgroundImageLayout = ImageLayout.None;
            loginBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            loginBtn.Location = new Point(301, 352);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(162, 49);
            loginBtn.TabIndex = 36;
            loginBtn.Text = "Login";
            loginBtn.UseVisualStyleBackColor = false;
            loginBtn.Click += loginBtn_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 33;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold);
            label2.Location = new Point(45, 126);
            label2.Name = "label2";
            label2.Size = new Size(82, 32);
            label2.TabIndex = 42;
            label2.Text = "Name";
            // 
            // nametxtbox
            // 
            nametxtbox.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold);
            nametxtbox.Location = new Point(182, 126);
            nametxtbox.Name = "nametxtbox";
            nametxtbox.Size = new Size(351, 39);
            nametxtbox.TabIndex = 43;
            // 
            // pintxtbox
            // 
            pintxtbox.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold);
            pintxtbox.Location = new Point(182, 243);
            pintxtbox.Name = "pintxtbox";
            pintxtbox.Size = new Size(351, 39);
            pintxtbox.TabIndex = 45;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold);
            label3.Location = new Point(45, 246);
            label3.Name = "label3";
            label3.Size = new Size(62, 32);
            label3.TabIndex = 44;
            label3.Text = "PIN";
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(701, 396);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(51, 25);
            logoutLinkLable.TabIndex = 46;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Back";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked_1;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(logoutLinkLable);
            Controls.Add(pintxtbox);
            Controls.Add(label3);
            Controls.Add(nametxtbox);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(loginBtn);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AdminForm";
            Text = "AdminForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Panel panel1;
        private Label label1;
        private Button loginBtn;
        private Panel panel2;
        private Label label2;
        private TextBox nametxtbox;
        private TextBox pintxtbox;
        private Label label3;
        private LinkLabel logoutLinkLable;
    }
}