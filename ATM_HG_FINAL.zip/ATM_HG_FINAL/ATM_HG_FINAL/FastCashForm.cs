﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_HG_FINAL
{
    public partial class FastCashForm : Form
    {
        public FastCashForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {//when the "X" is clicked it close the application
            Application.Exit();

        }
        //sets up  connection parameters to connect to a LocalDB 
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");
        public string AccNum = HomeForm.AccNum;

        private void b500Btn_Click(object sender, EventArgs e)
        {

           
                con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                //balanceres.Text = dt.Rows[0][0].ToString() + " Birr";
                int balance = Convert.ToInt32(dt.Rows[0][0].ToString());
            if ( 500 > balance)
                {
                    MessageBox.Show("Not Sufficient Balance");
                }
                else
                {
                    try
                    {
                        int newbalance = balance - 500;

                        string query = "update AccountTbl set Balance = " + newbalance + " where Accnum ='" + AccNum + "' ";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Take Your Money!");
                        HomeForm hm = new HomeForm();
                        hm.Show();
                        this.Hide();
                        con.Close();


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }

            }


            private void b1000Btn_Click(object sender, EventArgs e)
        {

            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            //balanceres.Text = dt.Rows[0][0].ToString() + " Birr";
            int balance = Convert.ToInt32(dt.Rows[0][0].ToString());
            if (1000 > balance)
            {
                MessageBox.Show("Not Sufficient Balance");
            }
            else
            {
                try
                {
                    int newbalance = balance - 1000;

                    string query = "update AccountTbl set Balance = " + newbalance + " where Accnum ='" + AccNum + "' ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Take Your Money!");
                    HomeForm hm = new HomeForm();
                    hm.Show();
                    this.Hide();
                    con.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void b2000Btn_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            //balanceres.Text = dt.Rows[0][0].ToString() + " Birr";
            int balance = Convert.ToInt32(dt.Rows[0][0].ToString());
            if (2000 > balance)
            {
                MessageBox.Show("Not Sufficient Balance");
            }
            else
            {
                try
                {
                    int newbalance = balance - 2000;

                    string query = "update AccountTbl set Balance = " + newbalance + " where Accnum ='" + AccNum + "' ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Take Your Money!");
                    HomeForm hm = new HomeForm();
                    hm.Show();
                    this.Hide();
                    con.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }

        private void b3000Btn_Click(object sender, EventArgs e)
        {

            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            //balanceres.Text = dt.Rows[0][0].ToString() + " Birr";
            int balance = Convert.ToInt32(dt.Rows[0][0].ToString());
            if (3000 > balance)
            {
                MessageBox.Show("Not Sufficient Balance");
            }
            else
            {
                try
                {
                    int newbalance = balance - 3000;

                    string query = "update AccountTbl set Balance = " + newbalance + " where Accnum ='" + AccNum + "' ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Take Your Money!");
                    HomeForm hm = new HomeForm();
                    hm.Show();
                    this.Hide();
                    con.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void b4000Btn_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            //balanceres.Text = dt.Rows[0][0].ToString() + " Birr";
            int balance = Convert.ToInt32(dt.Rows[0][0].ToString());
            if (4000 > balance)
            {
                MessageBox.Show("Not Sufficient Balance");
            }
            else
            {
                try
                {
                    int newbalance = balance - 4000;

                    string query = "update AccountTbl set Balance = " + newbalance + " where Accnum ='" + AccNum + "' ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Take Your Money!");
                    HomeForm hm = new HomeForm();
                    hm.Show();
                    this.Hide();
                    con.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }

        private void b5000Btn_Click(object sender, EventArgs e)
        {

            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select Balance from AccountTbl where Accnum = '" + AccNum + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            //balanceres.Text = dt.Rows[0][0].ToString() + " Birr";
            int balance = Convert.ToInt32(dt.Rows[0][0].ToString());
            if (5000 > balance)
            {
                MessageBox.Show("Not Sufficient Balance");
            }
            else
            {
                try
                {
                    int newbalance = balance - 5000;

                    string query = "update AccountTbl set Balance = " + newbalance + " where Accnum ='" + AccNum + "' ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Take Your Money!");
                    HomeForm hm = new HomeForm();
                    hm.Show();
                    this.Hide();
                    con.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void logoutLinkLable_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            //then it goes to the login page
            LoginForm log = new LoginForm();
            this.Hide();
            log.Show();
        }
    }
}
