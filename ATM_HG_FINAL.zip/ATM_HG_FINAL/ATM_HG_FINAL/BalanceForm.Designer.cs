﻿namespace ATM_HG_FINAL
{
    partial class BalanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label5 = new Label();
            label1 = new Label();
            label6 = new Label();
            balanceLable = new Label();
            accNumLabel = new Label();
            label2 = new Label();
            panel2 = new Panel();
            backBtn = new Button();
            logoutLinkLable = new LinkLabel();
            label3 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 43;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label6.Location = new Point(62, 254);
            label6.Name = "label6";
            label6.Size = new Size(105, 29);
            label6.TabIndex = 49;
            label6.Text = "Balance:";
            // 
            // balanceLable
            // 
            balanceLable.AutoSize = true;
            balanceLable.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            balanceLable.Location = new Point(272, 254);
            balanceLable.Name = "balanceLable";
            balanceLable.Size = new Size(0, 29);
            balanceLable.TabIndex = 50;
            // 
            // accNumLabel
            // 
            accNumLabel.AutoSize = true;
            accNumLabel.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            accNumLabel.Location = new Point(272, 182);
            accNumLabel.Name = "accNumLabel";
            accNumLabel.Size = new Size(108, 29);
            accNumLabel.TabIndex = 48;
            accNumLabel.Text = "Acc num";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label2.Location = new Point(322, 91);
            label2.Name = "label2";
            label2.Size = new Size(135, 29);
            label2.TabIndex = 45;
            label2.Text = "BALANCE";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 44;
            // 
            // backBtn
            // 
            backBtn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            backBtn.Location = new Point(317, 375);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(107, 42);
            backBtn.TabIndex = 47;
            backBtn.Text = "Back";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(700, 392);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(71, 25);
            logoutLinkLable.TabIndex = 51;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Logout";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked;
            logoutLinkLable.Click += logoutLinkLable_LinkClicked;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label3.Location = new Point(62, 182);
            label3.Name = "label3";
            label3.Size = new Size(204, 29);
            label3.TabIndex = 52;
            label3.Text = "Account Number:";
            // 
            // BalanceForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(logoutLinkLable);
            Controls.Add(panel1);
            Controls.Add(label6);
            Controls.Add(balanceLable);
            Controls.Add(backBtn);
            Controls.Add(accNumLabel);
            Controls.Add(label2);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "BalanceForm";
            Text = "BalanceForm";
            Load += BalanceForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Label label5;
        private Label label1;
        private Label label6;
        private Label label7;
        private Label label4;
        private Label label2;
        private Panel panel2;
        private Button backBtn;
        private LinkLabel logoutLinkLable;
        private Label balanceLable;
        private Label accNumLabel;
        private Label label3;
    }
}