﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_HG_FINAL
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            //when the "X" is clicked it close the application
            Application.Exit();
        }

     
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\HAYU\\DOCUMENTS\\HG_ATM_DB.MDF;Integrated Security=True;Connect Timeout=30");

        private void loginBtn_Click(object sender, EventArgs e)
        {
            con.Open();

            string password = pintxtbox.Text;
            string username = nametxtbox.Text.Trim();
            string query = "SELECT * FROM AdminTbl WHERE AdminName = @Username AND PIN = @Password";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);


                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Form1 register = new Form1();
                        register.Show();
                        this.Hide();

                    }
                    else
                    {
                        MessageBox.Show("Wrong Name Or PIN code");


                    }
                    con.Close();
                }
            }
        }

        private void logoutLinkLable_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoginForm back = new LoginForm();
            back.Show();
            this.Hide();

        }
    }
}
