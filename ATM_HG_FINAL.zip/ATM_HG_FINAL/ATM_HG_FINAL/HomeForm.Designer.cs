﻿namespace ATM_HG_FINAL
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            panel1 = new Panel();
            label1 = new Label();
            logoutLinkLable = new LinkLabel();
            changeBtn = new Button();
            transferBtn = new Button();
            depositeBtn = new Button();
            withdrawBtn = new Button();
            fastcshBtn = new Button();
            balanceBtn = new Button();
            AccountNumLabel = new Label();
            panel2 = new Panel();
            label2 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(717, 407);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(71, 25);
            logoutLinkLable.TabIndex = 30;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Logout";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked;
            // 
            // changeBtn
            // 
            changeBtn.BackColor = Color.FromArgb(0, 64, 64);
            changeBtn.BackgroundImageLayout = ImageLayout.None;
            changeBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            changeBtn.Location = new Point(465, 157);
            changeBtn.Name = "changeBtn";
            changeBtn.Size = new Size(162, 49);
            changeBtn.TabIndex = 29;
            changeBtn.Text = "Change PIN";
            changeBtn.UseVisualStyleBackColor = false;
            changeBtn.Click += changeBtn_Click;
            // 
            // transferBtn
            // 
            transferBtn.BackColor = Color.FromArgb(0, 64, 64);
            transferBtn.BackgroundImageLayout = ImageLayout.None;
            transferBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            transferBtn.Location = new Point(106, 360);
            transferBtn.Name = "transferBtn";
            transferBtn.Size = new Size(162, 49);
            transferBtn.TabIndex = 28;
            transferBtn.Text = "Transfer";
            transferBtn.UseVisualStyleBackColor = false;
            transferBtn.Click += transferBtn_Click;
            // 
            // depositeBtn
            // 
            depositeBtn.BackColor = Color.FromArgb(0, 64, 64);
            depositeBtn.BackgroundImageLayout = ImageLayout.None;
            depositeBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            depositeBtn.Location = new Point(106, 253);
            depositeBtn.Name = "depositeBtn";
            depositeBtn.Size = new Size(162, 49);
            depositeBtn.TabIndex = 27;
            depositeBtn.Text = "Deposit";
            depositeBtn.UseVisualStyleBackColor = false;
            depositeBtn.Click += depositeBtn_Click;
            // 
            // withdrawBtn
            // 
            withdrawBtn.BackColor = Color.FromArgb(0, 64, 64);
            withdrawBtn.BackgroundImageLayout = ImageLayout.None;
            withdrawBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            withdrawBtn.Location = new Point(465, 253);
            withdrawBtn.Name = "withdrawBtn";
            withdrawBtn.Size = new Size(162, 49);
            withdrawBtn.TabIndex = 26;
            withdrawBtn.Text = "Withdraw";
            withdrawBtn.UseVisualStyleBackColor = false;
            withdrawBtn.Click += withdrawBtn_Click;
            // 
            // fastcshBtn
            // 
            fastcshBtn.BackColor = Color.FromArgb(0, 64, 64);
            fastcshBtn.BackgroundImageLayout = ImageLayout.None;
            fastcshBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            fastcshBtn.Location = new Point(465, 360);
            fastcshBtn.Name = "fastcshBtn";
            fastcshBtn.Size = new Size(162, 49);
            fastcshBtn.TabIndex = 25;
            fastcshBtn.Text = "Fast Cash";
            fastcshBtn.UseVisualStyleBackColor = false;
            fastcshBtn.Click += fastcshBtn_Click;
            // 
            // balanceBtn
            // 
            balanceBtn.BackColor = Color.FromArgb(0, 64, 64);
            balanceBtn.BackgroundImageLayout = ImageLayout.None;
            balanceBtn.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            balanceBtn.Location = new Point(106, 157);
            balanceBtn.Name = "balanceBtn";
            balanceBtn.Size = new Size(162, 49);
            balanceBtn.TabIndex = 24;
            balanceBtn.Text = "Balance";
            balanceBtn.UseVisualStyleBackColor = false;
            balanceBtn.Click += balanceBtn_Click;
            // 
            // AccountNumLabel
            // 
            AccountNumLabel.AutoSize = true;
            AccountNumLabel.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            AccountNumLabel.Location = new Point(449, 80);
            AccountNumLabel.Name = "AccountNumLabel";
            AccountNumLabel.Size = new Size(185, 25);
            AccountNumLabel.TabIndex = 23;
            AccountNumLabel.Text = "Account Number";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 22;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label2.Location = new Point(258, 80);
            label2.Name = "label2";
            label2.Size = new Size(185, 25);
            label2.TabIndex = 31;
            label2.Text = "Account Number";
            // 
            // HomeForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(logoutLinkLable);
            Controls.Add(changeBtn);
            Controls.Add(transferBtn);
            Controls.Add(depositeBtn);
            Controls.Add(withdrawBtn);
            Controls.Add(fastcshBtn);
            Controls.Add(balanceBtn);
            Controls.Add(AccountNumLabel);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "HomeForm";
            Text = "HomeForm";
            Load += HomeForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Panel panel1;
        private Label label1;
        private LinkLabel logoutLinkLable;
        private Button changeBtn;
        private Button transferBtn;
        private Button depositeBtn;
        private Button withdrawBtn;
        private Button statementBtn;
        private Button balanceBtn;
        private Label AccountNumLabel;
        private Panel panel2;
        private Label label2;
        private Button fastcshBtn;
    }
}