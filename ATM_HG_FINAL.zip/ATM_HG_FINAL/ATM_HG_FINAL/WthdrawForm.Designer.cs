﻿namespace ATM_HG_FINAL
{
    partial class WthdrawForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            label1 = new Label();
            logoutLinkLable = new LinkLabel();
            label2 = new Label();
            panel2 = new Panel();
            AmountTxtbox = new TextBox();
            backBtn = new Button();
            withdraw1Btn = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label3.Location = new Point(62, 211);
            label3.Name = "label3";
            label3.Size = new Size(108, 29);
            label3.TabIndex = 47;
            label3.Text = "Amount:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 44;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(707, 394);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(71, 25);
            logoutLinkLable.TabIndex = 51;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Logout";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label2.Location = new Point(322, 91);
            label2.Name = "label2";
            label2.Size = new Size(154, 29);
            label2.TabIndex = 46;
            label2.Text = "WITHDRAW";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 45;
            // 
            // AmountTxtbox
            // 
            AmountTxtbox.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            AmountTxtbox.Location = new Point(301, 202);
            AmountTxtbox.Name = "AmountTxtbox";
            AmountTxtbox.Size = new Size(362, 36);
            AmountTxtbox.TabIndex = 50;
            // 
            // backBtn
            // 
            backBtn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            backBtn.Location = new Point(360, 377);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(107, 42);
            backBtn.TabIndex = 49;
            backBtn.Text = "Back";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // withdraw1Btn
            // 
            withdraw1Btn.BackColor = Color.FromArgb(0, 64, 64);
            withdraw1Btn.BackgroundImageLayout = ImageLayout.None;
            withdraw1Btn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            withdraw1Btn.Location = new Point(322, 291);
            withdraw1Btn.Name = "withdraw1Btn";
            withdraw1Btn.Size = new Size(162, 65);
            withdraw1Btn.TabIndex = 48;
            withdraw1Btn.Text = "Withdraw";
            withdraw1Btn.UseVisualStyleBackColor = false;
            withdraw1Btn.Click += withdraw1Btn_Click;
            // 
            // WthdrawForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(panel1);
            Controls.Add(logoutLinkLable);
            Controls.Add(label2);
            Controls.Add(panel2);
            Controls.Add(AmountTxtbox);
            Controls.Add(backBtn);
            Controls.Add(withdraw1Btn);
            FormBorderStyle = FormBorderStyle.None;
            Name = "WthdrawForm";
            Text = "WthdrawForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Panel panel1;
        private Label label5;
        private Label label1;
        private LinkLabel logoutLinkLable;
        private Label label2;
        private Panel panel2;
        private TextBox AmountTxtbox;
        private Button backBtn;
        private Button withdraw1Btn;
    }
}