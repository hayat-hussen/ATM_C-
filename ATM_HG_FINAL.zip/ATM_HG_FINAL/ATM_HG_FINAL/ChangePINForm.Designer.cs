﻿namespace ATM_HG_FINAL
{
    partial class ChangePINForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            label1 = new Label();
            label4 = new Label();
            confirmPINTxtbox = new TextBox();
            backBtn = new Button();
            label2 = new Label();
            panel2 = new Panel();
            newPINTxtbox = new TextBox();
            deposit1Btn = new Button();
            logoutLinkLable = new LinkLabel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label3.Location = new Point(62, 170);
            label3.Name = "label3";
            label3.Size = new Size(118, 29);
            label3.TabIndex = 36;
            label3.Text = "New PIN:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 68);
            panel1.TabIndex = 33;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(747, 0);
            label5.Name = "label5";
            label5.Size = new Size(54, 52);
            label5.TabIndex = 9;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Calligraphy", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(260, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 52);
            label1.TabIndex = 0;
            label1.Text = "HG ATM";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label4.Location = new Point(62, 249);
            label4.Name = "label4";
            label4.Size = new Size(161, 29);
            label4.TabIndex = 40;
            label4.Text = "Confirm PIN:";
            // 
            // confirmPINTxtbox
            // 
            confirmPINTxtbox.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            confirmPINTxtbox.Location = new Point(283, 249);
            confirmPINTxtbox.Name = "confirmPINTxtbox";
            confirmPINTxtbox.Size = new Size(362, 36);
            confirmPINTxtbox.TabIndex = 41;
            // 
            // backBtn
            // 
            backBtn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            backBtn.Location = new Point(363, 386);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(107, 42);
            backBtn.TabIndex = 38;
            backBtn.Text = "Back";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            label2.Location = new Point(322, 91);
            label2.Name = "label2";
            label2.Size = new Size(170, 29);
            label2.TabIndex = 35;
            label2.Text = "CHANGE PIN";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 64, 64);
            panel2.Location = new Point(-2, 435);
            panel2.Name = "panel2";
            panel2.Size = new Size(804, 16);
            panel2.TabIndex = 34;
            // 
            // newPINTxtbox
            // 
            newPINTxtbox.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            newPINTxtbox.Location = new Point(283, 170);
            newPINTxtbox.Name = "newPINTxtbox";
            newPINTxtbox.Size = new Size(362, 36);
            newPINTxtbox.TabIndex = 39;
            // 
            // deposit1Btn
            // 
            deposit1Btn.BackColor = Color.FromArgb(0, 64, 64);
            deposit1Btn.BackgroundImageLayout = ImageLayout.None;
            deposit1Btn.Font = new Font("Times New Roman", 14.8F, FontStyle.Bold);
            deposit1Btn.Location = new Point(342, 315);
            deposit1Btn.Name = "deposit1Btn";
            deposit1Btn.Size = new Size(162, 65);
            deposit1Btn.TabIndex = 37;
            deposit1Btn.Text = "Change";
            deposit1Btn.UseVisualStyleBackColor = false;
            deposit1Btn.Click += deposit1Btn_Click;
            // 
            // logoutLinkLable
            // 
            logoutLinkLable.AutoSize = true;
            logoutLinkLable.Font = new Font("Segoe UI", 11F);
            logoutLinkLable.LinkColor = Color.FromArgb(0, 64, 64);
            logoutLinkLable.Location = new Point(686, 397);
            logoutLinkLable.Name = "logoutLinkLable";
            logoutLinkLable.Size = new Size(71, 25);
            logoutLinkLable.TabIndex = 42;
            logoutLinkLable.TabStop = true;
            logoutLinkLable.Text = "Logout";
            logoutLinkLable.LinkClicked += logoutLinkLable_LinkClicked;
            // 
            // ChangePINForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(logoutLinkLable);
            Controls.Add(label3);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(confirmPINTxtbox);
            Controls.Add(backBtn);
            Controls.Add(label2);
            Controls.Add(panel2);
            Controls.Add(newPINTxtbox);
            Controls.Add(deposit1Btn);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ChangePINForm";
            Text = "ChangePINForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Panel panel1;
        private Label label5;
        private Label label1;
        private Label label4;
        private TextBox confirmPINTxtbox;
        private Button backBtn;
        private Label label2;
        private Panel panel2;
        private TextBox newPINTxtbox;
        private Button deposit1Btn;
        private LinkLabel logoutLinkLable;
    }
}